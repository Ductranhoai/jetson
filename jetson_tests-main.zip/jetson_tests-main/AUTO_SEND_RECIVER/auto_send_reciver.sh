#!/bin/bash


device_node_1="combox-master-1420422047065"
device_node_2="combox-node1-1423322058868"
device_node_3="combox-node2-1420422046571"
device_node_4="combox-node3-1421623004576"
device_node_5="combox-master-1420422047065"


path_script_1="/home/ubuntu/yolov7/jetson_tests/Gstreamer_And_Record/send.sh"
path_script_2="/root/Gstreamer_And_Record/send.sh"
path_script_3="/home/ubuntu/send.sh"
path_script_4="/home/ubuntu/send.sh"
path_script_5="/home/ubuntu/yolov7/jetson_tests/Gstreamer_And_Record/receiver.sh"

/mnt/c/Users/ASUS/adb/adb.exe -s "$device_node_1" shell $path_script_1 & pid1=$!
/mnt/c/Users/ASUS/adb/adb.exe -s "$device_node_2" shell $path_script_2 & pid2=$!
/mnt/c/Users/ASUS/adb/adb.exe -s "$device_node_3" shell $path_script_3 & pid3=$!
/mnt/c/Users/ASUS/adb/adb.exe -s "$device_node_4" shell $path_script_4 & pid4=$!
/mnt/c/Users/ASUS/adb/adb.exe -s "$device_node_5" shell $path_script_5 & pid5=$!

# sshpass -p "ubuntu" ssh ubuntu@192.168.1.59 & python3 path_identy_python.py

cleanup() { 

        device_nodes=("$device_node_1" "$device_node_2" "$device_node_3" "$device_node_4" "$device_node_5" )

        for i in ${!device_nodes[@]}; do
            remote_pids=$(/mnt/c/Users/ASUS/adb/adb.exe -s "${device_nodes[$i]}" shell ps aux | grep -i gst | awk '{print $2}')
            echo " "
            echo "IDs PIDs $remote_pids on device ${device_nodes[$i]}"
            for remote_pid in $remote_pids; do
                if [ -n "$remote_pid" ]; then
                    /mnt/c/Users/ASUS/adb/adb.exe -s "${device_nodes[$i]}" shell kill -9 $remote_pid
                    echo "Kill process id $remote_pid on device ${device_nodes[$i]}"
                else
                    echo "Process on device ${device_nodes[$i]} not found"
                fi
            done
        done

        exit

}

trap cleanup SIGINT

wait $pid1 $pid2 $pid3 $pid4 $pid5





# -- RUN 1 NODE--

# cleanup() {
#     if kill -0 $pid2 2>/dev/null; then
#         echo "Process $pid2 is still running"

#         remote_pid=$(/mnt/c/Users/ASUS/adb/adb.exe -s "$device_node_2" shell ps aux | grep -i gst | awk '{print $2}' )
#         echo "ID PID $remote_pid"

#         if [ -n "$remote_pid" ]; then
#             /mnt/c/Users/ASUS/adb/adb.exe -s "$device_node_2" shell kill -9 $remote_pid
#             echo "kill process id $remote_pid on device"
#         else
#             echo "Process on device not found"
#         fi
#     else
#         echo "Process $pid2 has already stopped"
#     fi
    
#     sudo fuser -k 5000/tcp
#     echo "cleaned port"
 
#     exit
# }
# trap cleanup SIGINT
# wait $pid2


