#!/bin/bash

#ID devices
device_node_1=""
device_node_2=""
device_node_3=""
device_node_4=""

#host Nodes 
host_node_1="10.10.0.1"
host_node_2="10.10.0.2"
host_node_3="10.10.0.3"
host_node_4="10.10.0.4"
# host_server=""


#video path
video_1=""
video_2=""
video_3=""
video_4=""

#path nfs mount
path_nfs_node1=""
path_nfs_node2=""
path_nfs_node3=""


#path script receiver on nfs 
path_script_1=""
path_script_2=""
path_script_3=""
path_script_4=""

#send 
gst-launch-1.0 -v \
    filesrc location="$video_1" ! qtdemux ! h264parse ! nvv4l2decoder ! nvvidconv! "video/x-raw,format=(string)I420,width=640,height=480" \
        ! matroskamux streamable=1 ! tcpserversink host=$host_node_1 port=5000 &
    filesrc location="$video_2" ! qtdemux ! h264parse ! nvv4l2decoder ! nvvidconv! "video/x-raw,format=(string)I420,width=640,height=480" \
        ! matroskamux streamable=1 ! tcpserversink host=$host_node_2 port=5000 &
    filesrc location="$video_3" ! qtdemux ! h264parse ! nvv4l2decoder ! nvvidconv! "video/x-raw,format=(string)I420,width=640,height=480" \
        ! matroskamux streamable=1 ! tcpserversink host=$host_node_3 port=5000 &
    filesrc location="$video_4" ! qtdemux ! h264parse ! nvv4l2decoder ! nvvidconv! "video/x-raw,format=(string)I420,width=640,height=480" \
        ! matroskamux streamable=1 ! tcpserversink host=$host_node_4 port=5000 &


# connect devices -> chroot and run script
echo "Connect-Run!"
/mnt/c/Users/ASUS/adb/adb.exe -s $device_node_1 shell $path_script_1 & pid_1=$! #adb Combox master - Comboxmasetr not chroot
pid_2=$(/mnt/c/Users/ASUS/adb/adb.exe -s $device_node_2 shell "chroot $path_nfs_node1 /bin/bash -c '$path_script_2 & echo \$!'")
pid_3=$(/mnt/c/Users/ASUS/adb/adb.exe -s $device_node_3 shell "chroot $path_nfs_node2 /bin/bash -c '$path_script_3 & echo \$!'")
pid_4=$(/mnt/c/Users/ASUS/adb/adb.exe -s $device_node_4 shell "chroot $path_nfs_node3 /bin/bash -c '$path_script_4 & echo \$!'")

#cleanup
# cleanup() {
#     devices_nodes=("$device_node_1" "$device_node_2" "$device_node_3" "$device_node_4")

#     for i in ${!devices_nodes[@]}; do
#         remote_clean_nodes=$(/mnt/c/Users/ASUS/adb/adb.exe -s "${devices_nodes[$i]}" shell ps aux | grep -i gst | ask '{print $2}')
#         echo"-----"
#         echo "IDs PIDs $remote_clean_nodes on device ${devices_nodes[$i]}"
#         for remote_pid in $remote_clean_nodes; do
#             if [ -n "$remote_pid" ]; then
#                 /mnt/c/Users/ASUS/adb/adb.exe -s "${devices_nodes[$i]}" shell kill -9 $remote_pid
#                 echo "Kill process id $remote_pid"
#             else
#                 echo "Process on devices ${devices_nodes[$i]} not found"
#             fi
#         done
#     done

#     exit 
# }


cleanup() {
    devices_nodes=("$device_node_2" "$device_node_3" "$device_node_4")
    nfs_share=("$path_nfs_node1" "$path_nfs_node2" "$path_nfs_node3")

    echo "kill process combox_master"
    remote_devices_node1=$(/mnt/c/Users/ASUS/adb/adb.exe -s "$device_node_1" shell ps aux | grep -i gst | awk '{print $2}')
    for remote_pid in $remote_devices_node1; do
        if [ -n "$remote_pid" ]; then
            /mnt/c/Users/ASUS/adb/adb.exe -s "$device_node_1" shell kill -9 $remote_pid
            echo "Killed process ID $remote_pid on node 1"
        else
            echo "No process found on node 1"
        fi
    done

    for i in ${!devices_nodes[@]}; do
        echo "Killing processes on device ${devices_nodes[$i]}"
        remote_devices=$(/mnt/c/Users/ASUS/adb/adb.exe -s "${devices_nodes[$i]}" shell chroot "${nfs_share[$i]}" ps aux | grep -i gst | awk '{print $2}')
        for remote_pid in $remote_devices; do
            if [ -n "$remote_pid" ]; then
                /mnt/c/Users/ASUS/adb/adb.exe -s "${devices_nodes[$i]}" shell chroot "${nfs_share[$i]}" kill -9 $remote_pid
                echo "Killed process ID $remote_pid on device ${devices_nodes[$i]}"
            else
                echo "No process found on device ${devices_nodes[$i]}"
            fi
        done
    done

    exit
}


trap cleanup SIGINT
wait $pid_1 $pid_2 $pid_3 $pid_4


