
import cv2
import torch
import numpy as np
import time  
import os
from models.experimental import attempt_load
from utils.general import non_max_suppression, scale_coords
from utils.datasets import letterbox
from utils.torch_utils import select_device
import warnings
warnings.filterwarnings("ignore", category=UserWarning, module="torch")


def detect():
    log_file_path = 'Frame_Time_TCP.log'

    if os.path.exists(log_file_path):
        os.remove(log_file_path)

    device = select_device('0')

    model = attempt_load('yolov7.pt', map_location=device)
    model.eval()


    #Use pipeline when 1 node send
    gst_pipeline = ("tcpclientsrc host=10.10.0.2 port=5000 ! queue"
                        "! matroskademux ! nvvidconv ! video/x-raw,format=(string)I420,width=640,height=480" 
                        "! videoconvert ! appsink sync=false")



    #Use pipeline when 3 node send
    # gst_pipeline = (
    #     "videomixer name=mix "
    #     "sink_0::xpos=0 sink_0::ypos=0 sink_0::width=640 sink_0::height=480 "
    #     "sink_1::xpos=640 sink_1::ypos=0 sink_1::width=640 sink_1::height=480 "
    #     "sink_2::xpos=0 sink_2::ypos=480 sink_2::width=640 sink_2::height=480 "
    #     "sink_3::xpos=640 sink_3::ypos=480 sink_3::width=640 sink_3::height=480 ! "
    #     "videoconvert ! appsink sync=false "
    #     "tcpclientsrc host=10.10.0.2 port=5000 ! queue ! matroskademux ! nvvidconv ! video/x-raw,format=(string)I420,width=640,height=480 ! mix.sink_0 "
    #     "tcpclientsrc host=10.10.0.3 port=5000 ! queue ! matroskademux ! nvvidconv ! video/x-raw,format=(string)I420,width=640,height=480 ! mix.sink_1 "
    #     "tcpclientsrc host=10.10.0.4 port=5000 ! queue ! matroskademux ! nvvidconv ! video/x-raw,format=(string)I420,width=640,height=480 ! mix.sink_2 "
    # )


    cap = cv2.VideoCapture(gst_pipeline, cv2.CAP_GSTREAMER)
    log_file = open(log_file_path, 'w')

    prev_time = time.time()
    frame_count = 0

    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break

        start_time = time.time()

        # frame = cv2.cvtColor(frame, cv2.COLOR_YUV2BGR_I420)

        img = letterbox(frame, new_shape=640)[0]
        img = img[:, :, ::-1].transpose(2, 0, 1)
        img = np.ascontiguousarray(img)
        img = torch.from_numpy(img).float().div(255.0).unsqueeze(0).to(device)

        with torch.no_grad():
            pred = model(img)[0]
            pred = non_max_suppression(pred, 0.25)

        if len(pred) > 0:
            det = pred[0]
            det[:, :4] = scale_coords(img.shape[2:], det[:, :4], frame.shape).round()
            for *xyxy, conf, cls in det:
                label = f'{model.names[int(cls)]} {conf:.2f}'
                plot_one_box(xyxy, frame, label=label)

        end_time = time.time()
        fps = 1.0 / (end_time - start_time)
        current_video_time = frame_count / fps
        frame_count += 1
        print(f'FPS: {fps:.2f},  Time: {current_video_time:.2f}s')
        log_file.write(f'FPS: {fps:.2f},  Time: {current_video_time:.2f}s\n')

        cv2.imshow('YOLOv7 Detection', frame)

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()
    log_file.close()


def plot_one_box(xyxy, img, color=(0, 255, 0), label=None, line_thickness=3):
    x1, y1, x2, y2 = map(int, xyxy)
    cv2.rectangle(img, (x1, y1), (x2, y2), color, line_thickness)
    if label:
        tf = max(line_thickness - 1, 1)
        t_size = cv2.getTextSize(label, 0, line_thickness / 3, tf)[0]
        c1 = (x1, y1 - t_size[1] - 3)
        c2 = (c1[0] + t_size[0] + 3, c1[1] + t_size[1] + 4)
        cv2.rectangle(img, c1, c2, color, -1)
        cv2.putText(img, label, (x1, y1 - 2), 0, line_thickness / 3, [255, 255, 255], thickness=tf, lineType=cv2.LINE_AA)

if __name__ == "__main__":
    detect()
