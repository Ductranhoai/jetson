#!/bin/bash

HOST_NODE_1="10.10.0.1" 

# Video path
video_1='/path/video/refinedet.mp4'
video_2='/path/video/yolo.mp4'
video_3='/path/video/pose.mp4'
video_4='/path/video/face.mp4'


gst-launch-1.0 -v \
    filesrc location="$video_1" ! qtdemux ! h264parse ! nvv4l2decoder ! nvvidconv! "video/x-raw,format=(string)I420,width=640,height=480" \
        ! matroskamux streamable=1 ! tcpserversink host=$HOST_NODE_1 port=5000

