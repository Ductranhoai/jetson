# SEND AND RECIVER VIDEO BY STREAMING NETWORK IN JETSON NANO


Send and reciver video over the network, in this method use "tcpserversink" to send video and "tcpclientsrc" to reciver video. It's linked together by host and port. 

Here, use Node to send video and Combox-master will receive then display on screen and object recognition.

## SEND VIDEO

```bash

#!/bin/bash

HOST_NODE_1="10.10.0.2" 

# Video path
video_1='/path/video/pose.mp4'
video_2='/path/video/yolo.mp4'
video_3='/path/video/pose.mp4'
video_4='/path/video/face.mp4'


gst-launch-1.0 -v \
    filesrc location="$video_2" ! qtdemux ! h264parse ! nvv4l2decoder ! nvvidconv! "video/x-raw,format=(string)I420,width=640,height=480" \
        ! matroskamux streamable=1 ! tcpserversink host=$HOST_NODE_1 port=5000

```

Use videomixer to send multiple videos at once from one Node.

```bash

#!/bin/bash

HOST_NODE_1="10.10.0.2" 

# Video path
video_1='/path/video/pose.mp4'
video_2='/path/video/yolo.mp4'
video_3='/path/video/pose.mp4'
video_4='/path/video/face.mp4'

gst-launch-1.0 -v \
    videomixer name=mix \
        sink_0::xpos=0 sink_0::ypos=0 sink_0::width=320 sink_0::height=240 \
        sink_1::xpos=320 sink_1::ypos=0 sink_1::width=320 sink_1::height=240 \
        sink_2::xpos=0 sink_2::ypos=240 sink_2::width=320 sink_2::height=240 \
        sink_3::xpos=320 sink_3::ypos=240 sink_3::width=320 sink_3::height=240 \
    ! nvvidconv ! matroskamux streamable=1 ! tcpserversink host=10.10.0.2 port=5000 \
    filesrc location="$video_1" ! qtdemux ! h264parse ! nvv4l2decoder ! nvvidconv! "video/x-raw,format=(string)I420,width=320,height=240" ! queue ! mix.sink_0 \
    filesrc location="$video_2" ! qtdemux ! h264parse ! nvv4l2decoder ! nvvidconv! "video/x-raw,format=(string)I420,width=320,height=240" ! queue ! mix.sink_1 \
    filesrc location="$video_3" ! qtdemux ! h264parse ! nvv4l2decoder ! nvvidconv! "video/x-raw,format=(string)I420,width=320,height=240" ! queue ! mix.sink_2 \
    filesrc location="$video_4" ! qtdemux ! h264parse ! nvv4l2decoder ! nvvidconv! "video/x-raw,format=(string)I420,width=320,height=240" ! queue ! mix.sink_3


```


## RECIVER VIDEO

Reciver video from each NODE:

```bash

#!/bin/bash

HOST_NODE_1="10.10.0.2"
HOST_NODE_2="10.10.0.3"
HOST_NODE_3="10.10.0.4"


gst-launch-1.0 -v \
    tcpclientsrc host=$HOST_NODE_1 port=5000 ! queue ! matroskademux ! nvvidconv ! "video/x-raw,format=(string)I420,width=640,height=480" ! videoconvert ! autovideosink sync=false

```

Receive video when multiple nodes send at the same time:

```bash
#!/bin/bash

HOST_NODE_1="10.10.0.2"
HOST_NODE_2="10.10.0.3"
HOST_NODE_3="10.10.0.4"

# --> RECEIVE FROM 3 DIFFERENT NODE <--
gst-launch-1.0 \
    videomixer name=mix \
        sink_0::xpos=0 sink_0::ypos=0 sink_0::width=640 sink_0::height=480 \
        sink_1::xpos=640 sink_1::ypos=0 sink_1::width=640 sink_1::height=480 \
        sink_2::xpos=0 sink_2::ypos=480 sink_2::width=640 sink_2::height=480 \
        sink_3::xpos=640 sink_3::ypos=480 sink_3::width=640 sink_3::height=480 \
    ! videoconvert ! autovideosink sync=false \
    tcpclientsrc host=$HOST_NODE_1 port=5000 ! queue ! matroskademux ! nvvidconv ! "video/x-raw,format=(string)I420,width=640,height=480" ! mix.sink_0 \
    tcpclientsrc host=$HOST_NODE_2 port=5000 ! queue ! matroskademux ! nvvidconv ! "video/x-raw,format=(string)I420,width=640,height=480" ! mix.sink_1 \
    tcpclientsrc host=$HOST_NODE_3 port=5000 ! queue ! matroskademux ! nvvidconv ! "video/x-raw,format=(string)I420,width=640,height=480" ! mix.sink_2 \


```


## PERFORM

Use file sent_video_rtp.sh to send video on each node and file reciver_video_rtp.sh to reciver and display on screen.

    - Step 1: Download source from github: git clone https://github.com/jerry-elinkgate/jetson_tests.git
    - Step 2: cd Video_Streaming_Network -> chmod +x * to grant permissions
    - Step 3: ./sent_video_rtp.sh and ./reciver_video_rtp.sh
    
To object recognition, run file identi.py.

    - Step 1: 
            + Download source Yolov7: git clone https://github.com/WongKinYiu/yolov7.git
            + Download file yolov7.pt: https://github.com/WongKinYiu/yolov7/releases/download/v0.1/yolov7.pt
    - Step 2: Run ./sent_video_rtp.sh from node, then run file identi.py to object recognition from video the node sends. The measured frame results are saved to file Frame_Time_TCP.log.
    
*NOTE: 
    
        + Save the identi.py file and yolov7.pt in the Yolov7 folder.
        + Change pipeline if only send video from 1 node or multiple nodes.



