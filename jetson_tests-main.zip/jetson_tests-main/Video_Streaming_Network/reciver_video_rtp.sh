
#!/bin/bash

HOST_NODE_1="10.10.0.2"

# --> RECIVER FROM 1 NODE
gst-launch-1.0 -v \
    tcpclientsrc host=$HOST_NODE_1 port=5000 ! queue ! matroskademux ! nvvidconv ! "video/x-raw,format=(string)I420,width=640,height=480" ! videoconvert ! autovideosink sync=false


# --> RECEIVE FROM 3 DIFFERENT NODE <--
gst-launch-1.0 \
    videomixer name=mix \
        sink_0::xpos=0 sink_0::ypos=0 sink_0::width=640 sink_0::height=480 \
        sink_1::xpos=640 sink_1::ypos=0 sink_1::width=640 sink_1::height=480 \
        sink_2::xpos=0 sink_2::ypos=480 sink_2::width=640 sink_2::height=480 \
        sink_3::xpos=640 sink_3::ypos=480 sink_3::width=640 sink_3::height=480 \
    ! videoconvert ! autovideosink sync=false \
    tcpclientsrc host=$HOST_NODE_1 port=5000 ! queue ! matroskademux ! nvvidconv ! "video/x-raw,format=(string)I420,width=640,height=480" ! mix.sink_0 \
    tcpclientsrc host=$HOST_NODE_2 port=5000 ! queue ! matroskademux ! nvvidconv ! "video/x-raw,format=(string)I420,width=640,height=480" ! mix.sink_1 \
    tcpclientsrc host=$HOST_NODE_3 port=5000 ! queue ! matroskademux ! nvvidconv ! "video/x-raw,format=(string)I420,width=640,height=480" ! mix.sink_2 \
