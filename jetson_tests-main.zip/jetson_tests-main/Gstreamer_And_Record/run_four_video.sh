
#!/bin/bash

screen_width=$(xdpyinfo | awk '/dimensions/{print $2}' | awk -Fx '{print $1}')
screen_height=$(xdpyinfo | awk '/dimensions/{print $2}' | awk -Fx '{print $2}')

width=$((screen_width / 2))
height=$((screen_height / 2))

# Video path
video_1='/home/ubuntu/yolov7/video/plate.mp4'
video_2='/home/ubuntu/yolov7/video/yolo.mp4'
video_3='/home/ubuntu/yolov7/video/refinedet.mp4'
video_4='/home/ubuntu/yolov7/video/road.mp4'

gst-launch-1.0 \
    videomixer name=mix \
        sink_0::xpos=0 sink_0::ypos=0 sink_0::width=$width sink_0::height=$height \
        sink_1::xpos=$width sink_1::ypos=0 sink_1::width=$width sink_1::height=$height \
        sink_2::xpos=0 sink_2::ypos=$height sink_2::width=$width sink_2::height=$height \
        sink_3::xpos=$width sink_3::ypos=$height sink_3::width=$width sink_3::height=$height \
    ! videoconvert ! autovideosink sync=false \
    filesrc location="$video_1" ! qtdemux ! h264parse ! nvv4l2decoder ! nvvidconv ! video/x-raw, format=I420, width=$width , height=$height ! videoconvert ! mix.sink_0 \
    filesrc location="$video_2" ! qtdemux ! h264parse ! nvv4l2decoder ! nvvidconv ! video/x-raw, format=I420, width=$width , height=$height ! videoconvert ! mix.sink_1 \
    filesrc location="$video_3" ! qtdemux ! h264parse ! nvv4l2decoder ! nvvidconv ! video/x-raw, format=I420, width=$width , height=$height ! videoconvert ! mix.sink_2 \
    filesrc location="$video_4" ! qtdemux ! h264parse ! nvv4l2decoder ! nvvidconv ! video/x-raw, format=I420, width=$width , height=$height ! videoconvert ! mix.sink_3 
    