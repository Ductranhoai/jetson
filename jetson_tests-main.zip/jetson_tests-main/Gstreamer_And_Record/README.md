# USE GSTREAMER TO PLAY VIDEO AND CAMERA WITH 2x2 LAYOUT - RECORD DATA FROM CAMERA TO MP4 FILE ON JETSON NANO


Handle videos and output videos on screen, in script use plugin like: videomixer, filesrc, qtdemux, h264parse, nvv4l2decoder, nvvidconv, videoconvert, autovideosink. These plugin do the jobs process the video, encode and decode the video, and display the video on the screen.

To be able to display content and save it from the camera, use "Tee" to split into two separate streams running parallel to each other. One stream to display the camera, one stream to save content from the camera to an mp4 file.


## Play video:

In run_four_video.sh, the script plays four videos with a 2x2 layout on the screen

```bash

#!/bin/bash

screen_width=$(xdpyinfo | awk '/dimensions/{print $2}' | awk -Fx '{print $1}')
screen_height=$(xdpyinfo | awk '/dimensions/{print $2}' | awk -Fx '{print $2}')

width=$((screen_width / 2))
height=$((screen_height / 2))

video_1='/home/ubuntu/yolov7/video/plate.mp4'
video_2='/home/ubuntu/yolov7/video/yolo.mp4'
video_3='/home/ubuntu/yolov7/video/refinedet.mp4'
video_4='/home/ubuntu/yolov7/video/pose.mp4'

gst-launch-1.0 \
    videomixer name=mix \
        sink_0::xpos=0 sink_0::ypos=0 sink_0::width=$width sink_0::height=$height \
        sink_1::xpos=$width sink_1::ypos=0 sink_1::width=$width sink_1::height=$height \
        sink_2::xpos=0 sink_2::ypos=$height sink_2::width=$width sink_2::height=$height \
        sink_3::xpos=$width sink_3::ypos=$height sink_3::width=$width sink_3::height=$height \
    ! videoconvert ! autovideosink sync=false \
    filesrc location="$video_1" ! qtdemux ! h264parse ! nvv4l2decoder ! nvvidconv ! video/x-raw, format=I420, width=$width , height=$height ! videoconvert ! mix.sink_0 \
    filesrc location="$video_2" ! qtdemux ! h264parse ! nvv4l2decoder ! nvvidconv ! video/x-raw, format=I420, width=$width , height=$height ! videoconvert ! mix.sink_1 \
    filesrc location="$video_3" ! qtdemux ! h264parse ! nvv4l2decoder ! nvvidconv ! video/x-raw, format=I420, width=$width , height=$height ! videoconvert ! mix.sink_2 \
    filesrc location="$video_4" ! qtdemux ! h264parse ! nvv4l2decoder ! nvvidconv ! video/x-raw, format=I420, width=$width , height=$height ! videoconvert ! mix.sink_3 
```


## Play video and camera:

In play_record.sh, the script to play the video, camera and record what the camera displays into an mp4 file.

```bash

#!/bin/bash

screen_width=$(xdpyinfo | awk '/dimensions/{print $2}' | awk -Fx '{print $1}')
screen_height=$(xdpyinfo | awk '/dimensions/{print $2}' | awk -Fx '{print $2}')

width=$((screen_width / 2))
height=$((screen_height / 2))

# Video path
video_1='/home/ubuntu/yolov7/video/plate.mp4'
video_2='/home/ubuntu/yolov7/video/yolo.mp4'
video_3='/home/ubuntu/yolov7/video/refinedet.mp4'
video_4='/home/ubuntu/yolov7/video/road.mp4'

camera1='/dev/video0'
camera2='/dev/video2'

gst-launch-1.0 \
    videomixer name=mix \
        sink_0::xpos=0 sink_0::ypos=0 sink_0::width=$width sink_0::height=$height \
        sink_1::xpos=$width sink_1::ypos=0 sink_1::width=$width sink_1::height=$height \
        sink_2::xpos=0 sink_2::ypos=$height sink_2::width=$width sink_2::height=$height \
        sink_3::xpos=$width sink_3::ypos=$height sink_3::width=$width sink_3::height=$height \
    ! videoconvert ! autovideosink sync=false \
    filesrc location="$video_1" ! qtdemux ! h264parse ! nvv4l2decoder ! nvvidconv ! video/x-raw, format=I420, width=$width , height=$height ! videoconvert ! mix.sink_0 \
    filesrc location="$video_2" ! qtdemux ! h264parse ! nvv4l2decoder ! nvvidconv ! video/x-raw, format=I420, width=$width , height=$height ! videoconvert ! mix.sink_1 \
    v4l2src device="$camera1" ! videoscale ! video/x-raw, width=$width, height=$height, format=YUY2 ! tee name=t1 \
        t1. ! queue ! videoconvert ! mix.sink_2 \
        t1. ! queue ! videoconvert ! x264enc speed-preset=ultrafast ! mp4mux ! filesink location=/home/ubuntu/yolov7/outputvideo/video1.mp4 -e \
    v4l2src device="$camera2" ! videoscale ! video/x-raw, width=$width, height=$height, format=YUY2 ! tee name=t2 \
        t2. ! queue ! videoconvert ! mix.sink_3 \
        t2. ! queue ! videoconvert ! x264enc speed-preset=ultrafast ! mp4mux ! filesink location=/home/ubuntu/yolov7/outputvideo/video2.mp4 -e \
```



## Run file run_four_video.sh

    * Step 1: Download source from github using " git clone https://github.com/jerry-elinkgate/jetson_tests.git "
    * Step 2: Open terminal -> cd jetson_test/resource_gst/
    * Step 3: Grant permissions to the file using: chmod +x *
    * Step 4: 
             - Play 4 videos with a 2x2 layout: ./run_four_video.sh
             - Play 2 video, 2 camera and record from camera: ./play_record.sh
