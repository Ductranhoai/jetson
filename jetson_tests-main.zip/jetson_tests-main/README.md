# USE STREAMING NETWORK TO SEND - RECEIVER VIDEO AND IDENTIFICATION REMOTE


## OVERVIEW


- Script auto_senf_reciver.sh is responsible for automatically running all sending and receiving scripts of nodes in Jetson using COMMAND PROMPT.
    * Nodes in jetson nano are responsible for sending video from Nodes to Combox-master.
    * Combo-master receives the video, then identifies it in the video and displays it on the screen.
    * To send and reciver video between Nodes to Combox-master, in the script use two plugin: tcpserversink - tcpclientsrc


## Script Send


```bash
#!/bin/bash

HOST_NODE_1="10.10.0.2" 

# Video path
video_1='/path/video/refinedet.mp4'
video_2='/path/video/yolo.mp4'
video_3='/path/video/pose.mp4'
video_4='/path/video/face.mp4'


gst-launch-1.0 -v \
    filesrc location="$video_2" ! qtdemux ! h264parse ! nvv4l2decoder ! nvvidconv! "video/x-raw,format=(string)I420,width=640,height=480" \
        ! matroskamux streamable=1 ! tcpserversink host=$HOST_NODE_1 port=5000

```


## Script Receiver 


```bash

#!/bin/bash

HOST_NODE_1="10.10.0.2"

# --> RECIVER FROM 1 NODE
gst-launch-1.0 -v \
    tcpclientsrc host=$HOST_NODE_1 port=5000 ! queue ! matroskademux ! nvvidconv ! "video/x-raw,format=(string)I420,width=640,height=480" ! videoconvert ! autovideosink sync=false


# --> RECEIVE FROM 3 DIFFERENT NODE <--
gst-launch-1.0 \
    videomixer name=mix \
        sink_0::xpos=0 sink_0::ypos=0 sink_0::width=640 sink_0::height=480 \
        sink_1::xpos=640 sink_1::ypos=0 sink_1::width=640 sink_1::height=480 \
        sink_2::xpos=0 sink_2::ypos=480 sink_2::width=640 sink_2::height=480 \
        sink_3::xpos=640 sink_3::ypos=480 sink_3::width=640 sink_3::height=480 \
    ! videoconvert ! autovideosink sync=false \
    tcpclientsrc host=$HOST_NODE_1 port=5000 ! queue ! matroskademux ! nvvidconv ! "video/x-raw,format=(string)I420,width=640,height=480" ! mix.sink_0 \
    tcpclientsrc host=$HOST_NODE_2 port=5000 ! queue ! matroskademux ! nvvidconv ! "video/x-raw,format=(string)I420,width=640,height=480" ! mix.sink_1 \
    tcpclientsrc host=$HOST_NODE_3 port=5000 ! queue ! matroskademux ! nvvidconv ! "video/x-raw,format=(string)I420,width=640,height=480" ! mix.sink_2 \


```

## Script Auto Send & Receiver

```bash

#!/bin/bash


device_node_1="combox-master-1420422047065"
device_node_2="combox-node1-1423322058868"
device_node_3="combox-node2-1420422046571"
device_node_4="combox-node3-1421623004576"
device_node_5="combox-master-1420422047065"


path_script_1="/home/ubuntu/yolov7/jetson_tests/Gstreamer_And_Record/send.sh"
path_script_2="/root/Gstreamer_And_Record/send.sh"
path_script_3="/home/ubuntu/send.sh"
path_script_4="/home/ubuntu/send.sh"
path_script_5="/home/ubuntu/yolov7/jetson_tests/Gstreamer_And_Record/receiver.sh"

/mnt/c/Users/ASUS/adb/adb.exe -s "$device_node_1" shell $path_script_1 & pid1=$!
/mnt/c/Users/ASUS/adb/adb.exe -s "$device_node_2" shell $path_script_2 & pid2=$!
/mnt/c/Users/ASUS/adb/adb.exe -s "$device_node_3" shell $path_script_3 & pid3=$!
/mnt/c/Users/ASUS/adb/adb.exe -s "$device_node_4" shell $path_script_4 & pid4=$!
/mnt/c/Users/ASUS/adb/adb.exe -s "$device_node_5" shell $path_script_5 & pid5=$!

sshpass -p "ubuntu" ssh ubuntu@192.168.1.59 & python3 path_identy_python.py

cleanup() { 

        device_nodes=("$device_node_1" "$device_node_2" "$device_node_3" "$device_node_4" "$device_node_5" )

        for i in ${!device_nodes[@]}; do
            remote_pids=$(/mnt/c/Users/ASUS/adb/adb.exe -s "${device_nodes[$i]}" shell ps aux | grep -i gst | awk '{print $2}')
            echo " "
            echo "IDs PIDs $remote_pids on device ${device_nodes[$i]}"
            for remote_pid in $remote_pids; do
                if [ -n "$remote_pid" ]; then
                    /mnt/c/Users/ASUS/adb/adb.exe -s "${device_nodes[$i]}" shell kill -9 $remote_pid
                    echo "Kill process id $remote_pid on device ${device_nodes[$i]}"
                else
                    echo "Process on device ${device_nodes[$i]} not found"
                fi
            done
        done

        exit

}

trap cleanup SIGINT

wait $pid1 $pid2 $pid3 $pid4 $pid5





# -- RUN 1 NODE--

# cleanup() {
#     if kill -0 $pid2 2>/dev/null; then
#         echo "Process $pid2 is still running"

#         remote_pid=$(/mnt/c/Users/ASUS/adb/adb.exe -s "$device_node_2" shell ps aux | grep -i gst | awk '{print $2}' )
#         echo "ID PID $remote_pid"

#         if [ -n "$remote_pid" ]; then
#             /mnt/c/Users/ASUS/adb/adb.exe -s "$device_node_2" shell kill -9 $remote_pid
#             echo "kill process id $remote_pid on device"
#         else
#             echo "Process on device not found"
#         fi
#     else
#         echo "Process $pid2 has already stopped"
#     fi
    
#     sudo fuser -k 5000/tcp
#     echo "cleaned port"
 
#     exit
# }
# trap cleanup SIGINT
# wait $pid2



``
